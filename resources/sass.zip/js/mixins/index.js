// import { sale as a } from './sale'
// import { print as b } from './print'
// import { invoice as c } from './invoice'
import { excelUtils as d } from './excelUtils'
// import { purchase as e } from './purchase'
// export const sale = { 
//   mixins: [a],
// }
// export const print = {
//   mixins: [b],
// }
// export const invoice = {
//   mixins: [c],
// }
export const excelUtils = {
  mixins: [d],
}
// export const purchase = {
//   mixins: [e],
// }