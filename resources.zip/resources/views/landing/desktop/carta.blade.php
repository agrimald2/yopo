    <div class="carta" id="carta">
        <div class="header-carta">
          <img src="images/black_circle.png" alt="">
          <p>CARTA</p>
        </div>
        <div class="row category_helper"></div>
        <div class="container row carta_row">
            <div class="col-5" onclick="location.href='/store/1';">

                <div class="row cat left_cat">
                    <div class="col-10">
                        <div class="rectangle_left">
                            Yopo Brasa
                        </div>
                        <div class="black_circle" style="background-image: url('https://images.rappi.pe/products/723843-1613406543689.jpg?d=128x90');"></div>
                    </div>
                </div>

            </div>
            <div class="col-2">
                <img src="images/right_leg.png" alt="" class="legs">
            </div>
            <div class="col-5" onclick="location.href='/store/2';">

                <div class="row cat left_cat">
                    <div class="col-2"></div>
                    <div class="col-10">
                        <div class="rectangle_right">
                            Yopo Fried
                        </div>
                        <div class="black_circle2" style="background-image: url('https://i.ibb.co/X5yBWXk/fried.png');"></div>
                    </div>
                </div>

            </div>
        </div>
        <div class="container row carta_row" style="margin-top:5vh">
            <div class="col-5" onclick="location.href='/store/3';">
                
                <div class="row cat left_cat">
                    <div class="col-10">
                        <div class="rectangle_left">
                            Yopo Frozen
                        </div>
                        <div class="black_circle" style="background-image: url('https://i.ibb.co/g6xGYKV/frozenr.png');"></div>
                    </div>
                </div>

            </div>
            <div class="col-2">
                <img src="images/left_leg.png" alt="" class="legs">
            </div>
            
            <div class="col-5" onclick="location.href='/store/4';">
                <div class="row cat left_cat">
                    <div class="col-2"></div>
                    <div class="col-10">
                        <div class="rectangle_right">
                            Postres
                        </div>
                        <div class="black_circle2" style="background-image: url('https://i.ibb.co/t8mzq2V/postresr.png');"></div>
                    </div>
                </div>
            </div>
        </div>
        <!--
        <a href="/store/1">
        <div class="row cat left_cat">
            <div class="col-9">
                <div class="rectangle_left">
                    Yopo Brasa
                </div>
                <div class="black_circle" style="background-image: url('https://images.rappi.pe/products/723843-1613406543689.jpg?d=128x90');"></div>
            </div>
            <div class="col-3">
                <img src="images/right_leg.png" alt="" class="legs">
            </div>
        </div>
        </a>

        <a href="/store/2">
        <div class="row cat left_cat">
            <div class="col-3">
                <img src="images/left_leg.png" alt="" class="legs">
            </div>
            <div class="col-9">
                <div class="rectangle_right">
                    Yopo Fried
                </div>
                <div class="black_circle2" style="background-image: url('https://i.ibb.co/X5yBWXk/fried.png');"></div>
            </div>
        </div>
        </a>

        <a href="/store/3">
        <div class="row cat left_cat">
            <div class="col-9">
                <div class="rectangle_left" style="color:#5895D3;">
                    Yopo Frozen
                </div>
                <div class="black_circle" style="background-image: url('https://i.ibb.co/g6xGYKV/frozenr.png');"></div>
            </div>
            <div class="col-3">
                <img src="images/right_leg.png" alt="" class="legs">
            </div>
        </div>
        </a>

        <a href="/store/4">
        <div class="row cat left_cat">
            <div class="col-3">
                <img src="images/left_leg.png" alt="" class="legs">
            </div>
            <div class="col-9">
                <div class="rectangle_right">
                    Postres
                </div>
                <div class="black_circle2" style="background-image: url('https://i.ibb.co/t8mzq2V/postresr.png');"></div>
            </div>
        </div>
        </a>-->
        <img id="comeyoponegro" src="images/come.png" alt="" style="width: 48vw;">
</div>