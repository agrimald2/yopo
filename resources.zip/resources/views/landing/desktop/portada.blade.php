<div class="portada" id="portada">
    <a href="#deliveries">    
    <img src="images/logo-portada.png" id="logo_portada" alt="COME YOPO" v-scroll-to="'#carta'">
    </a>
    <div class="yellow"></div>
    <div class="black"></div>
</div>
