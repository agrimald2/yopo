<template>
  <form @submit.prevent="submit" class="row">
    <div class="col-md-6">
      <div class="card">
        <div class="card-header">
          <h3 class="card-title">Nueva Oficina</h3>
        </div>
        <div class="card-body">
          <div class="row form-group">
            <div class="col">
              <label for="">Nombre</label>
              <input type="text" v-model="office.name" class="form-control" placeholder="Nombre" required>
            </div>
          </div>
          <div class="row form-group">
            <div class="col">
              <label for="">Desactivar Tienda Por HOY</label>
              <toggle-button v-model="office.disabled"></toggle-button>
            </div>
          </div>
          <div class="row">
            <div class="col">
              <button type="submit" class="btn btn-info float-right">
                <feather type="save"/>
                Guardar
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>  
  </form>
</template>

<script>
export default {
  mounted() {
    this.fetchData();
  },
  data() {
    return {
      office: {},
    }
  },
  methods: {
    fetchData() {
      let officeId = this.$route.params.officeId;
      axios.get(`offices/${officeId}`).then(res => {
        console.log(res);
        this.office = res.data.office;
      });
    },
    submit() {
      axios.put(`offices/${this.office.id}`, { office: this.office }).then(res => {
        console.log(res.data);
        this.$snotify.success('Se han guardado los cambios');
        // this.$router.push('/offices');
      }).catch(err => {
        console.log(err.response);
      });
    }
  }
}
</script>