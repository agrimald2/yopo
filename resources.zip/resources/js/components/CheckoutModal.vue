<template>
<div class="modal fade" id="checkoutModal" role="dialog" style="margin-top:10vh">
  <div class="modal-dialog">
    <form @submit.prevent="submit" class="modal-content" method="post" id="pay" name="pay">
      <div class="modal-header row">
        <div class="col-8">
          <h5>Total a pagar3: <strong>S/ {{ (transactionAmount).toFixed(2) }}</strong> </h5>
        </div>
        <div class="col-4" style="text-align:right">
          <img src="/images/black_circle.png" style="width:30%" alt="logo">
        </div>
      </div>
      <div class="modal-body position-relative">
        <div class="loading d-flex align-items-center" v-if="loading === 1">
          <h3 class="text-center w-100">Procesando...</h3>
        </div>
        <div class="loading d-flex align-items-center" v-if="loading === 2">
          <h3 class="text-center w-100 text-success">Pago realizado correctamente</h3>
        </div>
        <div class="loading d-flex align-items-center" v-if="loading === 3">
          <h3 class="text-center w-100 text-danger">No pudimos procesar el pago, Revise los datos de la tarjeta</h3>
        </div>
        <div class="form-row">
          <div class="col-7">
            <label for="cardName">Nombre y Apellido</label>
            <input id="cardholderName" data-checkout="cardholderName" v-model="cardholderName" type="text" class="form-control" placeholder="Nombres" required>
          </div>
          <div class="col-5">
            <label for="cardNumber">Número</label>
            <input id="cardNumber" data-checkout="cardNumber" @input="guessPaymentMethod" type="text" class="form-control" placeholder="5031 7557 3453 0604" required>
          </div>
        </div>
        <br>
        <div class="form-row">
          <div class="col-4">
            <label for="card_month">Mes</label>
            <select id="cardExpirationMonth" data-checkout="cardExpirationMonth" class="form-control" required>
              <option v-for="(item, index) in months"  :value="item" :key="index">{{ item }}</option>
            </select>
          </div>
          <div class="col-4">
            <label for="card_year">Año</label>
            <select id="cardExpirationYear" data-checkout="cardExpirationYear" class="form-control" required>
              <option v-for="(item, index) in years"  :value="item" :key="index">{{ item }}</option>
            </select>
          </div>
          <div class="col-4">
            <label for="card_year">CVV</label>
            <input id="securityCode" data-checkout="securityCode" type="text" class="form-control" placeholder="123" required>
          </div>
        </div>
        <br>
        <div class="form-row">
          <div class="col-6">
            <label for="card_doctype">Tipo DOC</label>
            <select id="docType" data-checkout="docType" v-model="docType" class="form-control" required>
              <option value="DNI" selected>DNI</option>
              <option value="RUC">RUC</option>
            </select>
          </div>
          <div class="col-6">
            <label for="card_docnumber">Número DOC</label>
            <input id="docNumber" data-checkout="docNumber" v-model="docNumber" type="text" class="form-control" placeholder="Numero de Documento" required>
          </div>
        </div>
        <br>
        <div class="form-row">
          <div class="col">
            <label for="email">E-mail</label>
            <input id="email" type="text" v-model="email" class="form-control" placeholder="cliente@yopo.pe">
          </div>
        </div>
      </div>
      <div class="modal-footer">  
        <button type="submit" class="btn btn-lg btn-block btn-warning" style="background-color: rgb(245, 166, 35)!important" :disabled="loading">
          Pagar
        </button>
      </div>
    </form>
  </div>
</div>
</template>

<script>
import { mapGetters, mapActions } from 'vuex'
import $ from "jquery";
import axios from 'axios';
var token = null;
console.log("process.env.NODE_ENV => ",process.env.NODE_ENV);
if (process.env.NODE_ENV === 'production') {
  // token = process.env.MIX_PUBLIC_TOKEN;
  token = 'APP_USR-46047350-e616-41ce-8565-17fe2a613714'
  console.log("token =>",token);
} else {
  console.log("process.env.MIX_TEST_PUBLIC_TOKEN =>",process.env.MIX_TEST_PUBLIC_TOKEN);
  token = process.env.MIX_TEST_PUBLIC_TOKEN;
}

export default {
  props: {
    transactionAmount: {
      type: Number,
      required: true,
    },
    description: {
      type: String,
      required: true,
    },
    installments: {
      type: Number,
      default: 1,
    },
    // sale: {
    //   type: null,
    // }
  },
  mounted() {
    this.loadMercadoPago();    
    console.log("this.token =>",this.token);
  },
  data() {
    return {
      loading: null,
      token: token,
      transaction_amount: null,
      payment_method_id: null,
      email: null,
      docType: 'DNI',
      docNumber: null,
      cardholderName: null,
      years: [
        2021,
        2022,
        2023,
        2024,
        2025,
        2026
      ],
      months: [
        '01',
        '02',
        '03',
        '04',
        '05',
        '06',
        '07',
        '08',
        '09',
        '10',
        '11',
        '12',
      ]      
    }
  },
  computed: {
    ...mapGetters({
      sale: 'sale/getSale',
      products: 'sale/products',
      totalProducts: 'sale/totalProducts',
    }),
  },
  methods: {
    submit() {
      console.log("submit() ==>");
      $('#checkoutModal').modal({
        keyboard: false,
        backdrop: false,
      });
      this.loading = 1;
      const $form = document.querySelector('#pay');      
      Mercadopago.createToken($form, this.sdkResponseHandler.bind(this));
    },
    loadMercadoPago() {
      Mercadopago.getIdentificationTypes();
      console.log("loadMercadoPago this.token =>",this.token);
      Mercadopago.setPublishableKey(this.token);
    },
    guessPaymentMethod() {
      let cardnumber = document.getElementById("cardNumber").value;
      if (cardnumber.length >= 6) {
        let bin = cardnumber.substring(0,6);
        console.log("cardnumber.substring(0,6) =>",cardnumber.substring(0,6));
        Mercadopago.getPaymentMethod({ "bin": bin }, this.setPaymentMethod.bind(this));
      }
    },
    setPaymentMethod(status, response) {
      console.log("setPaymentMethod status =>",status);
      console.log("setPaymentMethod response =>",response);
      console.log("response[0]",response[0]);
      if (status == 200 && response[0]) {
        let paymentMethodId = response[0].id;
        this.paymentMethodId = paymentMethodId;
      } else {
        document.getElementById("cardNumber").value = ''
        alert(`payment method info error => ${response.message}`);        
      }
    }, 
    getInstallments() {
      Mercadopago.getInstallments({
        payment_method_id: this.payment_method_id,
        amount: 1,
      }, function (status, response) {
        if (status == 200) {
          document.getElementById('installments').options.length = 0;
          response[0].payer_costs.forEach(installment => {
            let opt = document.createElement('option');
            opt.text = installment.recommended_message;
            opt.value = installment.installments;
            document.getElementById('installments').appendChild(opt);
          });
        } else {
          alert(`installments method info error: ${response}`);
        }
      });
    },
    sdkResponseHandler(status, response) {
      console.log("status =>",status)
      console.log("response =>",response)
      if (status != 200 && status != 201) {
        let msg = "";
        for (let data in response.cause) {
          console.log("response.cause[data].code",response.cause[data].code);
          msg += response.cause[data].code + "-" + response.cause[data].description;
        }
        console.log("msg =>",msg);
        alert(msg);
        this.loading = 3;
      } else {
        let inventories = [];
        this.products.forEach(item => {
          inventories.push(...this.checkInventory(item));
        });
        axios.post('/api/sales/shop', {
          inventories, 
          sale: this.sale,
          paymentMethodId: this.paymentMethodId,
          transactionAmount: this.transactionAmount,
          installments: this.installments,
          email: this.email,
          cardholderName: this.cardholderName,
          docType: this.docType,
          docNumber: this.docNumber,
          description: this.description,
          token: response.id,
        }).then(res => {
          console.log("axios.post('/api/sales/shop') =>",res);
          this.loading = 2;
          $('#checkoutModal').modal({
            keyboard: true,
            backdrop: true,
          });
          setTimeout(() => { 
            this.loading = null; 
            $('#checkoutModal').modal('hide');
            this.$emit('confirm', res.data);
          }, 3000);
        }).catch(error => {
          this.loading = false;
          $('#checkoutModal').modal({
            keyboard: true,
            backdrop: true,
          });
          this.loading = 3;
          setTimeout(() => {
            this.loading = null; 
            this.$emit('error', error.response);
          }, 3000);
          console.log(error.response);
        });
      }
    }
  }
}
</script>

<style>
.loading-text {
  z-index: 2;
  height: calc(100% - 2rem);
  width: calc(100% - 2rem);
  position: absolute;
}

.loading {
  z-index: 1;
  background: white;
  height: calc(100% - 2rem);
  width: calc(100% - 2rem);
  position: absolute;
}

.creditCardForm {
    max-width: 700px;
    background-color: #fff;
    margin: 100px auto;
    overflow: hidden;
    padding: 25px;
    color: #4c4e56;
}
.creditCardForm label {
    width: 100%;
    margin-bottom: 10px;
}
.creditCardForm .heading h1 {
    text-align: center;
    font-family: 'Open Sans', sans-serif;
    color: #4c4e56;
}
.creditCardForm .payment {
    float: left;
    font-size: 18px;
    padding: 10px 25px;
    margin-top: 20px;
    position: relative;
}
.creditCardForm .payment .form-group {
    float: left;
    margin-bottom: 15px;
}
.creditCardForm .payment .form-control {
    line-height: 40px;
    height: auto;
    padding: 0 16px;
}
.creditCardForm .owner {
    width: 63%;
    margin-right: 10px;
}
.creditCardForm .CVV {
    width: 35%;
}
.creditCardForm #card-number-field {
    width: 100%;
}
.creditCardForm #expiration-date {
    width: 49%;
}
.creditCardForm #credit_cards {
    width: 50%;
    margin-top: 25px;
    text-align: right;
}
.creditCardForm #pay-now {
    width: 100%;
    margin-top: 25px;
}
.creditCardForm .payment .btn {
    width: 100%;
    margin-top: 3px;
    font-size: 24px;
    background-color: #2ec4a5;
    color: white;
}
.creditCardForm .payment select {
    padding: 10px;
    margin-right: 15px;
}
.transparent {
    opacity: 0.2;
}
@media(max-width: 650px) {
    .creditCardForm .owner,
    .creditCardForm .CVV,
    .creditCardForm #expiration-date,
    .creditCardForm #credit_cards {
        width: 100%;
    }
    .creditCardForm #credit_cards {
        text-align: left;
    }
}
</style>